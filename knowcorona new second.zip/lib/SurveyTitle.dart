class SurveyTitle{

  String title;
  String route;
  int pagenumber;

  SurveyTitle(this.title, this.pagenumber, this.route);


}