//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,

//             children: [
           
//               Image(
//                 image: AssetImage('Images/virus.png'),
//               ),
//               SizedBox(height: 20.0),
//               Text('Purify \n Our Motherland \n from COVID-19',
//                 textAlign: TextAlign.center,
//                 style: TextStyle(color: Colors.grey[700], fontFamily: 'Seg',
//                   fontSize: 22.0, fontWeight: FontWeight.bold,),
//               ),
//               SizedBox(height: 30.0),

//               Stack(
//                 alignment: Alignment.topCenter,
//                 children: <Widget>[
//                   Image(
//                   image: AssetImage('Images/flagtwo.png'),
//                     ),
//                  Image(image: AssetImage('Images/language.png'),
//                     ),
//                   Positioned(
//                     bottom: 0,
//                     child:
//                     Image(image: AssetImage('Images/arrow.png'),
//                     ),
//                   )

//                 ],
//   ),

// ]
//           ),



// this is the back up for the questionaire list